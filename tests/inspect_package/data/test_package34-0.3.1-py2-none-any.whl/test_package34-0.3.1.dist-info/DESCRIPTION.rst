longer description of the package


