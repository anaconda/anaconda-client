'''
@author: sean
'''

#from setuptools import setup, find_packages
from distutils.core import setup

setup(
    name='test_package34',
    version="0.3.1",
    license="custom",
    author='Sean Ross-Ross',
    author_email='srossross@gmail.com',
    url='http://github.com/binstar/binstar_pypi',
    packages=['package1'],
    description='Python test package for binstar client',
    long_description='longer description of the package',
    requires=['requests (>=2.0,<=3.0)',
                      'pyyaml (==2.0)',
                      'pytz'],

)


