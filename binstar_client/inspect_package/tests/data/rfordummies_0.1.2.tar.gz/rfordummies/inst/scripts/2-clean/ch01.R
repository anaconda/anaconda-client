# Chapter 1 - Introducing R: The Big Picture

# Recognizing the Benefits of Using R

## It comes as free, open-source code

### It runs anywhere

### It supports extensions

### It provides an engaged community

### It connects with other languages


# Looking At Some of the Unique Features of R

## Performing multiple calculations with vectors

x <- 1:5
x
x + 2
x + 6:10

## Processing more than just statistics

## Running code without a compiler




